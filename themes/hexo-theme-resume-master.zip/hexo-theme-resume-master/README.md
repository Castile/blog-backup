# 简历主题

示例：https://mxclub.github.io/resume

文档：https://xaoxuu.com/wiki/hexo-theme-resume/

示例源码：https://github.com/xaoxuu/resume-example

主题源码：https://github.com/xaoxuu/hexo-theme-resume
